DECLARE @StartDate DATETIME = '7/1/2025' /*days*/
DECLARE @ToDate DATETIME = '7/31/2025'

DECLARE @MyTiUserAgentPrefix NVARCHAR(50)
SELECT @MyTiUserAgentPrefix = cfg.SettingValue FROM dbo.Configuration cfg WHERE cfg.SettingKey = 'MyTiUserAgentPrefix'

SELECT COUNT(*) TotalLogins, SUM(DATEDIFF(MINUTE, us.CreatedDate, us.UpdatedDate)) MinutesSpent, u.userid, u.EmailAddress 
,u.Address ,u.City, u.State, u.ZipCode--, us.IPAddress
FROM dbo.UserSessionsArchive us
INNER JOIN dbo.[User] u ON u.UserId = us.UserId
WHERE us.UserAgent LIKE @MyTiUserAgentPrefix + '%'
    AND us.CreatedDate >= @StartDate
    AND us.UpdatedDate <= @ToDate
	--AND u.UserId IN (21068)
GROUP BY u.userid, u.EmailAddress, u.Address ,u.City, u.State, u.ZipCode--, us.IPAddress
ORDER BY MinutesSpent DESC